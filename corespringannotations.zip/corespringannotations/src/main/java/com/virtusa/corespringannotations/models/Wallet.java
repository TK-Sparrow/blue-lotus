package com.virtusa.corespringannotations.models;

public class Wallet {

}
