package com.virtusa.corespringannotations.models;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Import(Payment.class)
public class Transaction {
	
	private int transId;
	@Autowired
	private Date dot;
	private long amount;
	private Account account;
	
	
   @Autowired
     public Transaction( Account account)
	{
		
		this.account=account;
	}
   public Account getAccount()
	{
		return account;
	}
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public Date getDot() {
		return dot;
	}
	
	@Autowired
	@Qualifier(value = "date2") //resolve ambiguity--autowired by type
	public void setDot(Date dot) {
		this.dot = dot;
	}
	
	
	
	
	
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
	
	@Bean
	@Lazy //lazy binding
	public ATM getATMInstance()
	{
		return new ATM();
	}
	
	
	
	

}
