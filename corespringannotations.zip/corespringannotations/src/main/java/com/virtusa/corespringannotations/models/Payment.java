package com.virtusa.corespringannotations.models;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Payment {
public boolean isValidate()
{
return isValidate();
}
}
