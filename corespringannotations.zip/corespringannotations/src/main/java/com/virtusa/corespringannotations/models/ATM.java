package com.virtusa.corespringannotations.models;

public class ATM {
	
	private long referenceNo;
	private String location;
	public long getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(long referenceNo) {
		this.referenceNo = referenceNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Wallet getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
