package com.virtusa.corespringannotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.corespringannotations.models.ATM;
import com.virtusa.corespringannotations.models.Payment;
import com.virtusa.corespringannotations.models.Transaction;
import com.virtusa.corespringannotations.models.Wallet;

/**
 * Spring annotations
 *
 */
public class App 
{
    @SuppressWarnings("resource")
	public static void main( String[] args )
    {
       ApplicationContext context=new ClassPathXmlApplicationContext("com/virtusa/corespringannotatios" +"/resources/application-bean.xml");
       
       //IOC
       Transaction transaction=(Transaction) context.getBean("transaction");
       transaction.setTransId(34567);
       transaction.setAmount(77886);
       System.out.println(transaction.getDot().toString());
       System.out.println(transaction.getAccount());
      
       System.out.println(transaction.getTransId());
       
       //ATM details
       
       ATM atm=transaction.getATMInstance();
       atm.setLocation("Perungudi");
       atm.setReferenceNo(376543546);
       System.out.println(transaction.getATMInstance().getLocation());
       ATM payment=transaction.getATMInstance();
       Wallet wallet=payment.getInstance();
       
    }
}
