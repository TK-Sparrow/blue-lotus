package com.virtusa.day8springlifecycle.models;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

@Component(value="vehicle")
public class Vehicle implements BeanClassLoaderAware,BeanNameAware,BeanFactoryAware,ResourceLoaderAware,ApplicationEventPublisherAware,BeanPostProcessor,InitializingBean {
	
	private String regNo;
	private String maker;
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	@Override
	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println(name);
		
	}
	@Override
	public void setBeanClassLoader(ClassLoader classLoader) {
		// TODO Auto-generated method stub
		System.out.println(classLoader.getClass().getName());
		
	}
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println(beanFactory.isSingleton("vehicle"));
		
	}
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		// TODO Auto-generated method stub
		System.out.println(applicationEventPublisher.getClass().getName());
	}
	@Override
	public void setResourceLoader(ResourceLoader resourceLoader) {
		// TODO Auto-generated method stub
		System.out.println(resourceLoader.getClass().getName());
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("properties are ready");
		
	}
	@PostConstruct
	public void Init() {
		System.out.println("Invoking after property");
	}
	
	public void destroyBean() {
		System.out.println("before destroy");
	}
}
