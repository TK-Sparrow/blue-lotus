package com.virtusa.insurance08springlifecycle.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sun.org.apache.bcel.internal.generic.NEW;
import com.virtusa.insurance08springlifecycle.models.PolicyHolder;
import com.virtusa.insurance08springlifecycle.validators.PolicyHolderValidator;

@Controller
public class PolicyHolderController {
	@Autowired
	private PolicyHolderValidator policyHolderValidator;
	
	@ModelAttribute("genderList")
	public List<String> getAllGender(){
		List<String> genders=new ArrayList<String>();
		genders.add("male");
		genders.add("female");
		return genders;
	}
	
	@GetMapping("/loadpolicyholder")
	public ModelAndView loadPolicyHolder() {
		return new ModelAndView("addpolicyholder","policyHolder",new PolicyHolder());
		
	}
	@PostMapping("/addPolicyHolder")
	public String addPolicyHolder(@ModelAttribute("policyHolder") @Validated PolicyHolder policyHolder,BindingResult result) {
		String viewName=null;
		if(policyHolder!=null) {
			
			policyHolderValidator.validate(policyHolder,result);
			
			if(result.hasErrors()) {
				viewName="addpolicyholder";
			}
			else {
				System.out.print(policyHolder.getInsureName());
				viewName="home";
			}
		}
		else {
			viewName="addpolicyholder";
		}
		return viewName;
		
	}
	
}
