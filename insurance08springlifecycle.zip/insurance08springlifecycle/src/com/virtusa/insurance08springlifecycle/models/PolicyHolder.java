package com.virtusa.insurance08springlifecycle.models;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class PolicyHolder {
		private String insureName;
		private long mobileNo;
		private String gender;
		private String address;
		private LocalDate dob;
		@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
		private String email;
		public String getInsureName() {
			return insureName;
		}
		public void setInsureName(String insureName) {
			this.insureName = insureName;
		}
		public long getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
		public LocalDate getDob() {
			return dob;
		}
		@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
		public void setDob(LocalDate dob) {
			this.dob = dob;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
		
}
