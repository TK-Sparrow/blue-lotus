package com.virtusa.insurance08springlifecycle.validators;

import java.time.LocalDate;

import org.apache.tomcat.dbcp.pool2.impl.BaseGenericObjectPool;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.virtusa.insurance08springlifecycle.models.PolicyHolder;
@Component
public class PolicyHolderValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		PolicyHolder policyHolder=(PolicyHolder) target;
		if(policyHolder.getDob().isAfter(LocalDate.now())) {
			errors.rejectValue("dob", "Data Error",new Object[]{"'dob'"}, "Date of the Birth can't be future Value");
		}
		else {
			
		}
	}

}
