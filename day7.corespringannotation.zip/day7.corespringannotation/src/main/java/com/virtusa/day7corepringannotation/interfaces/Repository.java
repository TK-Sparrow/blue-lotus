package com.virtusa.day7corepringannotation.interfaces;

public interface Repository 
{
String getName();
}
