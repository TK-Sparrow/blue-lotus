package com.virtusa.day7.corespringannotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.day7.corespringannotation.model.DbHelper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext context=new ClassPathXmlApplicationContext("com/virtusa/day7/corespringannotation/resources/annotation-bean.xml");
		
		  DbHelper dbhelper=(DbHelper) context.getBean("dbhelper");
		  System.out.println(dbhelper.getRepository().getName());
		 
    }
}
