package com.virtusa.day7.corespringannotation.implementation;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.virtusa.day7corepringannotation.interfaces.Repository;
@Component
@Primary
public class HibernateRepository implements Repository
{
	@Override
 public String getName() {
	 return "Hibernet Repo";
 }
}
