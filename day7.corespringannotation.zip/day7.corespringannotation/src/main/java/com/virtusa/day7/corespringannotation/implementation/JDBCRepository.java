package com.virtusa.day7.corespringannotation.implementation;

import org.springframework.stereotype.Component;

import com.virtusa.day7corepringannotation.interfaces.Repository;
@Component
public class JDBCRepository implements Repository
{
@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "JDBC repo";
	}

	
}
