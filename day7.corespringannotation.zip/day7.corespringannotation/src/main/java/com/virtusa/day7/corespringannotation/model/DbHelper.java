package com.virtusa.day7.corespringannotation.model;

import org.springframework.stereotype.Component;

import com.virtusa.day7corepringannotation.interfaces.Repository;
@Component(value="dbhelper")
public class DbHelper 
{
private Repository repository;

public DbHelper(Repository repo)
{
	this.repository=repo;
}
public Repository getRepository()
{
	return repository;
}

}
